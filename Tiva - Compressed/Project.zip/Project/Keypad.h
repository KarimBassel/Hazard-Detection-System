#include "types.h"

void Keypad_Init();
unsigned char Keypad_Read();
