#include <stdio.h>
#include "types.h"

void Laser_Init();