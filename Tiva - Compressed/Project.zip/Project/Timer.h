
#include "types.h"
#include <stdio.h>

void Timer0A_Init(void);