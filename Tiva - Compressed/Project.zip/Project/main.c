#include "DIO.h"
#include "TM4c123gh6pm.h"
#include <stdio.h>
#include "Timer.h"
#include "Ultrasonic.h"
#include "Magnetic.h"
#include "Laser.h"
#include "Bluetooth.h"
volatile uint32 counter=0;
/* global variables to store and display distance in cm*/
uint32 time; /*stores pulse on time */
uint32 distance; /* stores measured distance value */
char mesg[20];  /* string format of distance value */
unsigned int adc_value;
int main()
{
  HC05_init();
  Laser_Init();
  Magnetic_Init();
  Smoke_init();
  Timer0ACapture_init();  /*initialize Timer0A in edge edge time */
  GPIO_PORTB_DATA_R &= ~(0x10);
  //GPIO_PORTB_DATA_R = 0x10; //laser
  while(1){ 
    //Code for magnetic sensor
    if((DIO_ReadPin(&GPIO_PORTC_DATA_R ,6)) == 0x0){
      GPIO_PORTF_DATA_R = 0x2;
    }
    else{
     Bluetooth_Write_String("Intrusion Detect\n");
     Detect_Magnet();
     GPIO_PORTF_DATA_R &= ~(0x2);
   }     
   // end code magnetic sensor
   // Ultrasonic sensor code
      time = Measure_distance(); /* take pulse duration measurement */ 
      distance = (time * 10625)/10000000; /* convert pulse duration into distance */
      if (distance <20){
        Bluetooth_Write_String("Motion Detected\n");
        Detect_Motion();
      }
      sprintf(mesg, "\r\nDistance = %d cm", distance); /*convert float type distance data into string */
      printstring(mesg); /*transmit data to computer */
      Delay(2000);
      // end code ultrasonic sensor
      
      //smoke sensor code
      ADC0_PSSI_R |= (1<<3);        /* Enable SS3 conversion or start sampling data from AN0 */
        while((ADC0_RIS_R & 8) == 0) ;   /* Wait untill sample conversion completed*/
        adc_value = ADC0_SSFIFO3_R; /* read adc coversion result from SS3 FIFO*/
        ADC0_ISC_R = 8;          /* clear coversion clear flag bit*/
			/*control Green PF3->LED */
	if(adc_value >= 900){
        Bluetooth_Write_String("Smoke Detected\n");
        Detect_Smoke();
	GPIO_PORTF_DATA_R  = 0x08; /* turn on green LED*/
        }
	else if(adc_value < 900){
	GPIO_PORTF_DATA_R  &= ~(0x8); /* turn off green LED*/
        sprintf(mesg, "\r\nFume = %d", adc_value); /*convert float type distance data into string */
        printstring(mesg); /*transmit data to computer */
        }
        // end code smoke sensor
      
  }
  return 0;
}

