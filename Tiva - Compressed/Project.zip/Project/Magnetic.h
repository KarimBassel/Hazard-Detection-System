#include <stdio.h>
#include "types.h"

void Magnetic_Init();
void Detect_Magnet();