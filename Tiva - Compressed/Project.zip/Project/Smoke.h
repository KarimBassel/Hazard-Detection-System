#include <stdio.h>
#include "types.h"

void Smoke_init();
void Detect_Smoke();